CREATE DATABASE quan_ly_sach;
GO

CREATE TABLE danh_muc
(
    id int IDENTITY(1, 1) PRIMARY KEY,
    ten_danh_muc NVARCHAR(255) NOT NULL,
);

GO

CREATE TABLE sach
(
    id int IDENTITY(1, 1) PRIMARY KEY,
    ten_sach NVARCHAR(255) NOT NULL,
    ma_sach NVARCHAR(10) NOT NULL UNIQUE,
    ngay_nhap DATE NOT NULL,
    so_luong int NOT NULL DEFAULT 0,
    danh_muc_id int NOT NULL,
    constraint FK_Sach_DanhMuc foreign key (danh_muc_id) references danh_muc(id)
);

GO

INSERT INTO danh_muc(ten_danh_muc)
    VALUES
    ('Kinh tế'),
    ('CNTT');

GO

INSERT INTO sach(ten_sach, ma_sach, ngay_nhap, so_luong, danh_muc_id)
    VALUES
    ('SQL High Performance', 'CNTT123', '2020-09-14', 12, 2),
    ('Kinh tế đại cương', 'KT213', '2020-04-21', 43, 1),
    ('Kinh tế vĩ mô', 'KT512', '2019-03-20', 42, 1);

GO
